from flask import Flask, request, jsonify, render_template
import google.generativeai as genai
import os

app = Flask(__name__)

# Configure Gemini API
GEMINI_API_KEY = os.getenv('GEMINI_API_KEY', 'AIzaSyAslYzZYuv0QyAKiHoeuLGGjAudgDCL7Hw')
genai.configure(api_key=GEMINI_API_KEY)

# Set up the model
generation_config = {
    "temperature": 0.7,
    "top_p": 1,
    "top_k": 1,
    "max_output_tokens": 2048,
}

safety_settings = [
    {
        "category": "HARM_CATEGORY_HARASSMENT",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
    },
    {
        "category": "HARM_CATEGORY_HATE_SPEECH",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
    },
    {
        "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
    },
    {
        "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
    },
]

model = genai.GenerativeModel(
    model_name="gemini-1.5-flash",
    generation_config=generation_config,
    safety_settings=safety_settings
)

# System prompt for IPL chatbot
system_prompt = """You are an expert IPL (Indian Premier League) chatbot assistant. 
Your role is to provide accurate, up-to-date information about:
- IPL teams, players, and statistics
- Match schedules and results
- Tournament history and records
- Player transfers and team compositions
- Fun facts and trivia about IPL

Always respond in a friendly, conversational tone. If you don't know an answer, say you don't know rather than making something up.

Current year is 2024, and the latest IPL season is IPL 2024."""

chat_session = model.start_chat(history=[])

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json['message']
    
    try:
        # Send message to Gemini with the system prompt
        response = chat_session.send_message(
            f"{system_prompt}\n\nUser: {user_message}"
        )
        
        return jsonify({
            'status': 'success',
            'response': response.text
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'response': f"Sorry, I encountered an error: {str(e)}"
        })

if __name__ == '__main__':
    app.run(debug=True)